package game.arkanoid.fxml;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class MainTest {

    @Test
    public void testAddNumbers() {
        assertEquals(5, 5);
    }
}
